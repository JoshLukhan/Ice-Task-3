/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package icetask.q.pkg1;

/**
 *
 * @author Josh
 */
public class ICETASKQ1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       String s1 = "{}{)}";
        String s2 = "";
        String s3 = "{[}]";
        String s4 = "()";
        String s5 = "({[]})";
        
        System.out.println("Is '" + s1 + "' valid? " + isValid(s1)); // flase
        System.out.println("Is '" + s2 + "' valid? " + isValid(s2)); // false
        System.out.println("Is '" + s3 + "' valid? " + isValid(s3)); // false
        System.out.println("Is '" + s4 + "' valid? " + isValid(s4)); // true
        System.out.println("Is '" + s5 + "' valid? " + isValid(s5)); // true
    }
    public static boolean isValid(String s) {
        StringBuilder stack = new StringBuilder();
        for (char c : s.toCharArray()) {
            if (c == '(' || c == '{' || c == '[') {
                stack.append(c);
            } else {
                if (stack.length() == 0) {
                    return false; 
                }
                char last = stack.charAt(stack.length() - 1);
                if ((c == ')' && last == '(') || (c == '}' && last == '{') || (c == ']' && last == '[')) {
                    stack.deleteCharAt(stack.length() - 1); 
                } else {
                    return false; 
                }
            }
        }
        return stack.length() == 0; 
    }
}
