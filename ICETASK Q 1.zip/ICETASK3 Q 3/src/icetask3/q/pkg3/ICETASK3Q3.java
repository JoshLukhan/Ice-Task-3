/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package icetask3.q.pkg3;

import java.util.Scanner;

/**
 *
 * @author Josh
 */
public class ICETASK3Q3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       System.out.println("please enter 2 numbers");
       Scanner scanner = new Scanner(System.in);
       int a = scanner.nextInt();
        int b = scanner.nextInt();
        int gcdResult = greatestCommonDivisor(a, b);
        System.out.println("The greatest common divisor of " + a + " and " + b + " is: " + gcdResult);
    }
    
     public static int greatestCommonDivisor(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }
    
}
