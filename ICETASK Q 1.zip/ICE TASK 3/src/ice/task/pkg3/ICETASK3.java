/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ice.task.pkg3;
import java.util.Iterator;

/**
 *
 * @author Josh
 */
public class ICETASK3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
        int limit = 100; // Example limit
        OddSquaresSum generator = new OddSquaresSum(limit);
        int sum = 0;
        while (generator.hasNext()) {
            int nextNumber = generator.next();
            if (nextNumber > limit) {
                break;
            }
            sum += nextNumber;
        }
        System.out.println("Sum of squares of odd numbers up to " + limit + " is: " + sum);
    }
        
        public static class OddSquaresSum implements Iterator<Integer> {
    private int currentNumber = 1;
    private int limit;

    public OddSquaresSum(int limit) {
        this.limit = limit;
    }

    
    public boolean hasNext() {
        return true; // Always true for an infinite sequence
    }

    
    public Integer next() {
        int oddNumber = currentNumber;
        currentNumber += 2;
        if (currentNumber > limit) {
            throw new IllegalStateException("Limit exceeded");
        }
        return oddNumber * oddNumber;
    }
        }
    
}
